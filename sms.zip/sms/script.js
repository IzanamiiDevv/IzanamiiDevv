function showResult(title, message, icon) {
  const iconn = icon ? icon.toLowerCase() : "";
  if (iconn === "error"){
   playShortAudio("error.mp3");
  }
  Swal.fire({
    title: title,
    html: message,
    icon: iconn,
  //  showCancelButton: true,
    confirmButtonColor: "#0061ff",
  // cancelButtonColor: "#d33",
    confirmButtonText: "Okay"
  });
}

let sound = null;
function playMusic(url, isalang, isLoop){
  if (sound != null) {
    sound.stop();
    sound.unload();
    sound = null;
  }
   sound = new Howl({
      src: [url],
      loop: isLoop,
      format: ['mp3'],
      volume: 1,
      onend: () => {}
    });
  if (isalang){
    sound.play();
  }
}

function playShortAudio(url){
  const s = new Howl({
    src: [url],
    loop: false,
    volume: 1,
    autoplay: true
  });
  s.play();
}
async function submitForm() {
   event.preventDefault();
   const cookies = document.getElementById('cookies');
   const link = document.getElementById('urls');
   const result = document.getElementById('result');
   const button = document.getElementById('submit-button');
   const select = document.getElementById('items');
   const selectedItem = select.options[select.selectedIndex].value;
   if (!cookies.value || !link.value){
     return showResult("Error", "Please input your appstate and post link.", "error");
   }
   try {
     result.style.display = 'block';
     result.style.backgroundColor = '#0061ff';
     result.style.color = '#ffffff';
     result.innerHTML = "Please Wait.. try checking your post react"
       
     button.style.display = 'none';
     const response = await fetch('/react', {
       method: 'POST',
       body: JSON.stringify({
         cookie: cookies.value,
         link: link.value,
         type: selectedItem.toUpperCase()
        }),
       headers: {
         'Content-Type': 'application/json',
       },
     });
     const data = await response.json();
     
     if (data) {
     result.style.display = 'block';
     result.style.backgroundColor = '#0061ff';
     result.style.color = '#ffffff';
     result.innerHTML = data.message;
     button.style.display = 'block';
     } else {
     result.style.backgroundColor = '#3D1619';
     result.style.color = '#ffffff';
     result.innerHTML = 'Error: Something went wrong...';
     button.style.display = 'block';
     playShortAudio("error.mp3");
     }
   } catch (e) {
     console.error(e);
     result.style.backgroundColor = '#3D1619';
     result.style.color = '#ffffff';
     result.innerHTML = 'Error: Something went wrong...';
     button.style.display = 'block';  
     playShortAudio("error.mp3");
   }
 }
 
function rainbow(div,text){
  let k = 0;
  let pogi = new Array();
  let neth = new Array("#FF0000", "#FF4000", "#FF8000", "#FFC000", "#FFFF00", "#C0FF00", "#80FF00", "#40FF00", "#00FF00", "#00FF40", "#00FF80", "#00FFC0", "#00FFFF", "#00C0FF", "#0080FF", "#0040FF", "#0000FF", "#4000FF", "#8000FF", "#C000FF", "#FF00FF", "#FF00C0", "#FF0080", "#FF0040");
  const startColor = () => {
    for (var b = 0; b < pogi.length; b++) {
      document.getElementById(b).style.color = neth[b]
    }
    for (var c = 0; c < neth.length; c++) {
      neth[c - 1] = neth[c]
    }
    neth[neth.length - 1] = neth[-1];
    setTimeout(() => startColor(), 50);
  }
  while (neth.length<text.length){neth=neth.concat(neth);}
  while (k<=text.length){pogi[k]=text.charAt(k);k++;}
  for(var d=0;d<pogi.length;d++){div.innerHTML+=`<span id='${d}' class='${d}'>${pogi[d]}</span>`}
  startColor();
}
const result = document.getElementById('result');
const footertxt = document.getElementById('pogiako');
//rainbow(footertxt, "© 2024 | Created by Kent Joshua Cervantes");
result.style.display = 'block';
result.style.backgroundColor = '#0061ff';
result.style.color = '#ffffff';
result.innerHTML = `Please contact me if you experienced a problem:<br><a style="text-decoration: underline; color: white;" href="https://www.facebook.com/profile.php?id=100068255737079"><b>👉 Cervantes 👈</b></a>`;
let file = "NethBgmusic";
let getm = localStorage.getItem(file);
let s = false;
function switchie1(b) {
  let pogika = document.getElementById("pogika");
  playMusic("FB_VID_8187911807065092653.mp3", b, true);
  pogika.innerHTML = (b ? "🎧" : "⚙️") + " CervTools";
}
const pogika = document.getElementById("pogika");
pogika.addEventListener('click', () => {
    s=!s;
    let succ=s?"1":"0";
    switchie1(s);
    localStorage.setItem(file, succ);
    return;
});
s=getm==="1"?true:false;
switchie1(s);
//setTimeout(() => showResult("Welcome to CervTools ⚙️", "This is strictly <b><font color=red>NOT FOR SALE.</font></b><br>Please contact the developer if you had problem.", "info"), 500);