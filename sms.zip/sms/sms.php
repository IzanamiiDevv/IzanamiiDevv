<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, User-Agent, Referer");

if (isset($_POST["button"])){
function filterMobileNumber($number) {
    if (substr($number, 0, 1) === '0') {
        $number = substr($number, 1);
    }
    return $number;
}
$mobileNumber = trim($_POST["number"]);
$mobile = filterMobileNumber($mobileNumber);
$input = $_POST["message"];
$message = urlencode($input);
$id = rand(100000, 999999);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.saudiallahuakbar.xyz/v13/sms.php');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    "User-Agent: Dalvik/2.1.0 (Linux; U; Android 8.1.0; CPH1823 Build/O11019)",
    "Host: api.saudiallahuakbar.xyz"));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, '$Oj0O%K7zi2j18E=%5B%22free.text.sms%22%2C%22403%22%2C%22%2B63'.$mobile.'%22%2C%22CPH1823%22%2C%22cTBjX_ShRD6CGPbqi68aGV%3AAPA91bGwIgbaKhoC8zBPenH6U53bbMU8I-Cx8UiHWDXAWChKKmLCkI3nPMPWx117Zhc56PyJFltEisddqSpKaQP941aDAGQB4LQZ4RHPipbRwYZ-iMebDRlA2aoH5H5eoQbmCoXp3Q9D%22%2C%22'.$message.'+++++++++++++-freed0m%22%2C%22%22%5D&device_id='.$id.'&humottae=Processing');
$result = curl_exec($ch);

$link = explode('"', explode('"message":"', $result)[1])[0];

}

?>

<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
     <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap">
     <link rel="stylesheet" href="style.css">
     <title>CervTools | Sms</title>
     <style>
      #log { height: 100px; background: #f7f7f7; overflow: auto; color: black; }
     </style>
   </head>
   <body>
     <script src="https://cdn.jsdelivr.net/npm/axios@1.7.2/dist/axios.min.js"></script>
      <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
       <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
       <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>
       <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
       <script src="https://cdn.jsdelivr.net/npm/howler@2.2.4/dist/howler.min.js"></script>
       <div>
         <nav class="ws navbar navbar-expand-lg navbar-dark">
           <a class="navbar-brand" href="#">
           <h1 id="pogika"></h1>
           </a>
           <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
             <span class="navbar-toggler-icon"></span>
           </button>
           <div style="font-size: 11px; margin-top: 10px; padding: 5px; border: 2px solid white; border-radius: 10px; background-color: #0061ff; color: white; font-weight: 800;" class="collapse navbar-collapse justify-content-end" id="navbarNav">
             <ul class="navbar-nav">
               </li>
               <li class="nav-item active">
                 <a style="display: none;" class="nav-link" href="/">Home</a>
                 <a style="" class="nav-link" href="https://kent-tools.wuaze.com/profile/index.html">Developer Info</a>
               </li>
               <li class="nav-item dropdown">
                 <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">More Tools</a>
                 <div style="font-weight: 800; margin: 0;" class="dropdown-menu" aria-labelledby="navbarDropdown">
                   <a class="dropdown-item" href="https://kent-tools.wuaze.com/tools/sms/sms.php">Sms</a>
                   <a class="dropdown-item" href="https://kent-tools.wuaze.com/tools/nglSpammer/nglSpamm.php">Ngl spammer</a>
                   <a class="dropdown-item" href="https://kent-tools.wuaze.com/tools/translator/translator.php">Translator</a>
                 </div>
               </li>
             </ul>
           </div>
         </nav>
<div style="padding:30px" class="wrapper-container">
         <div style="position:center;" class="form-wrapper">
            <form method="post" id="from" action="sms.php" class="form-container">
               <div class="form-item">
                  <label for="cookies">Number:</label>
                  <input type="text" id="num" name="number" placeholder="Number">
               </div>
               <div class="form-item">
                  <label for="urls">Message:</label>
                  <input type="text" id="msg" name="message" placeholder="Message">
               </div>
               <div class="form-item">
                  <button class="button1" type="submit" name="button" id="submit-button">SUBMIT</button>
               </div>
                 <div id="log">Logs</div>
               <script>
               document.getElementById('log').innerHTML = "<?php echo $link; ?>";
               </script><br>
               <div class="form-item">
                  <div style="font-size: 11px" id="result"></div>
               </div>
            </form>
         </div>
         </div>
        <footer>
        <span id="pogiako" style="font-size: 12px; letter-spacing: 1px; font-weight: 800; text-align: center;">© 2024 | Created by Kent Joshua Cervantes</span>
       </footer>
    <script src="script.js"></script>
    <script>
    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    }
</script>
  </div>
  </body>
</html>
